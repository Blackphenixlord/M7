var mySnakeBoard = new SNAKE.Board({
  boardContainer: "game-area",
  fullScreen: true,
  premoveOnPause: false
});
